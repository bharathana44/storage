package com.ikano.dmsmigrationannualdata.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PathDataTest {
    @Test
    void testAccountDataCsv() {
        String expectedCsv = "test/account.csv";
        PathData pathData = new PathData();
        pathData.setAccountDataCsv(expectedCsv);
        assertEquals(expectedCsv, pathData.getAccountDataCsv());
    }

    @Test
    void testSummaryDataCsv() {
        String expectedCsv = "test/summary.csv";
        PathData pathData = new PathData();
        pathData.setSummaryDataCsv(expectedCsv);
        assertEquals(expectedCsv, pathData.getSummaryDataCsv());
    }

    @Test
    void testDestPdfPath() {
        String expectedPath = "test/pdf/";
        PathData pathData = new PathData();
        pathData.setDestPdfPath(expectedPath);
        assertEquals(expectedPath, pathData.getDestPdfPath());
    }
}