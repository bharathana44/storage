package com.ikano.dmsmigrationannualdata.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HeadingsTest {
    @Test
    void testHeadingsValues() {
        Headings headings = new Headings();
        headings.setAccountCSVDefaultPath("path/to/account.csv");
        headings.setSummaryCSVDefaultPath("path/to/summary.csv");
        headings.setPdfDestPath("path/to/pdf/destination");
        headings.setSavingsAccount("Savings Account");
        headings.setLoanAccount("Loan Account");
        headings.setTillVaxtAccount("Tillväxt Account");
        headings.setBorsAccount("Börs Account");
        headings.setSsn("SSN");
        headings.setEngagementNumber("Engagement Number");
        headings.setEngagementType("Engagement Type");
        headings.setStatusText("Status Text");
        headings.setProductText("Product Text");
        headings.setCapitalSharePercentage("Capital Share Percentage");
        headings.setReceivedInterestSharePercentage("Received Interest Share Percentage");
        headings.setPaidInterestSharePercentage("Paid Interest Share Percentage");
        headings.setYearConcerned("Year Concerned");
        headings.setSumReceivedInterest("Sum Received Interest");
        headings.setSumPreliminaryTax("Sum Preliminary Tax");
        headings.setSumPaidInterest("Sum Paid Interest");
        headings.setName("Name");
        headings.setCareOfAddress("Care of Address");
        headings.setStreetAddress("Street Address");
        headings.setPostalCode("Postal Code");
        headings.setCity("City");
        assertEquals("path/to/account.csv", headings.getAccountCSVDefaultPath());
        assertEquals("path/to/summary.csv", headings.getSummaryCSVDefaultPath());
        assertEquals("path/to/pdf/destination", headings.getPdfDestPath());
        assertEquals("Savings Account", headings.getSavingsAccount());
        assertEquals("Loan Account", headings.getLoanAccount());
        assertEquals("Tillväxt Account", headings.getTillVaxtAccount());
        assertEquals("Börs Account", headings.getBorsAccount());
        assertEquals("SSN", headings.getSsn());
        assertEquals("Engagement Number", headings.getEngagementNumber());
        assertEquals("Engagement Type", headings.getEngagementType());
        assertEquals("Status Text", headings.getStatusText());
        assertEquals("Product Text", headings.getProductText());
        assertEquals("Capital Share Percentage", headings.getCapitalSharePercentage());
        assertEquals("Received Interest Share Percentage", headings.getReceivedInterestSharePercentage());
        assertEquals("Paid Interest Share Percentage", headings.getPaidInterestSharePercentage());
        assertEquals("Year Concerned", headings.getYearConcerned());
        assertEquals("Sum Received Interest", headings.getSumReceivedInterest());
        assertEquals("Sum Preliminary Tax", headings.getSumPreliminaryTax());
        assertEquals("Sum Paid Interest", headings.getSumPaidInterest());
        assertEquals("Name", headings.getName());
        assertEquals("Care of Address", headings.getCareOfAddress());
        assertEquals("Street Address", headings.getStreetAddress());
        assertEquals("Postal Code", headings.getPostalCode());
        assertEquals("City", headings.getCity());
    }
}