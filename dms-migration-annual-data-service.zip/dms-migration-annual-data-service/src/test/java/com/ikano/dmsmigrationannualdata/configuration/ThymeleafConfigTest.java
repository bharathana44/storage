package com.ikano.dmsmigrationannualdata.configuration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest(classes = ThymeleafConfig.class)
@EnableWebMvc
@TestPropertySource(locations = "classpath:application.properties")
class ThymeleafConfigTest {
    @Autowired
    private SpringTemplateEngine templateEngine;

    @Autowired
    private ClassLoaderTemplateResolver templateResolver;

    @Test
    public void testTemplateEngineNotNull() {
        assertNotNull(templateEngine);
    }

    @Test
    public void testTemplateResolverNotNull() {
        assertNotNull(templateResolver);
    }

    @Test
    public void testTemplateResolverPrefix() {
        assertEquals("/templates/", templateResolver.getPrefix());
    }

    @Test
    public void testTemplateResolverSuffix() {
        assertEquals(".html", templateResolver.getSuffix());
    }

    @Test
    public void testTemplateResolverTemplateMode() {
        assertEquals("HTML", templateResolver.getTemplateMode().toString());
    }
}