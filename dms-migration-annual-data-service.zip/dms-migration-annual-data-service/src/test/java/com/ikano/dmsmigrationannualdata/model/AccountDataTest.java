package com.ikano.dmsmigrationannualdata.model;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AccountDataTest {

    private AccountData accountData;

    @BeforeEach
    public void setUp() {
        accountData = new AccountData();
    }

    @Test
    void testAccountName() {
        // Set account name
        String accountName = "Savings Account";
        accountData.setAccountName(accountName);

        // Verify account name
        assertEquals(accountName, accountData.getAccountName());
    }

    @Test
    void testDataHolder() {
        // Create data holder list
        List<DataHolder> dataHolderList = new ArrayList<>();
        dataHolderList.add(new DataHolder("Data1", "Value1"));
        dataHolderList.add(new DataHolder("Data2", "Value2"));

        // Set data holder list
        accountData.setDataHolder(dataHolderList);

        // Verify data holder list
        assertEquals(dataHolderList, accountData.getDataHolder());
    }

    @Test
    void testBalanceShare() {
        // Set balance share
        String balanceShare = "1000";
        accountData.setBalanceShare(balanceShare);

        // Verify balance share
        assertEquals(balanceShare, accountData.getBalanceShare());
    }

    @Test
    void testInterestShare() {
        // Set interest share
        String interestShare = "500";
        accountData.setInterestShare(interestShare);

        // Verify interest share
        assertEquals(interestShare, accountData.getInterestShare());
    }
}