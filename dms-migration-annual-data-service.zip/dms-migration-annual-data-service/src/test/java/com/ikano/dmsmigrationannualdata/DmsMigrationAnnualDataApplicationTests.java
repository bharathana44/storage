package com.ikano.dmsmigrationannualdata;

import com.ikano.dmsmigrationannualdata.service.CsvProcessorService;
import com.ikano.dmsmigrationannualdata.service.PdfService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class DmsMigrationAnnualDataApplicationTests {
    @InjectMocks
    private DmsMigrationAnnualDataApplication dmsMigrationAnnualDataApplication;

    @Mock
    private CsvProcessorService csvProcessorService;
    @Mock
    private PdfService pdfServiceMock;

    @BeforeEach
     void setUp() {
        dmsMigrationAnnualDataApplication.setAccountDataCsv("accountData.csv");
        dmsMigrationAnnualDataApplication.setSummaryDataCsv("summaryData.csv");
        dmsMigrationAnnualDataApplication.setDestPath("destPath.pdf");


    }

    @Test
     void testValidArguments() throws Exception {
        dmsMigrationAnnualDataApplication.run(null);
        verify(csvProcessorService).generatePdf(any());
    }

    @Test
     void testNullAccountDataCsv() {
        dmsMigrationAnnualDataApplication.setSummaryDataCsv(null);
        dmsMigrationAnnualDataApplication.run(null);
        verifyNoInteractions(csvProcessorService);
    }

    @Test
     void testNullSummaryDataCsv() {
        dmsMigrationAnnualDataApplication.setSummaryDataCsv(null);
        dmsMigrationAnnualDataApplication.run(null);
        verifyNoInteractions(csvProcessorService);
    }

    @Test
     void testNullDestPath() {
        dmsMigrationAnnualDataApplication.setDestPath(null);
        dmsMigrationAnnualDataApplication.run(null);
        verifyNoInteractions(csvProcessorService);
    }

    @Test
     void testVerifyPathData() throws Exception {
        //String[] args = {"accountData.csv", "summaryData.csv", "destPath.pdf"};
        dmsMigrationAnnualDataApplication.run(null);
        verify(csvProcessorService).generatePdf(argThat(pathData -> {
            return pathData.getAccountDataCsv().equals("accountData.csv") &&
                    pathData.getSummaryDataCsv().equals("summaryData.csv") &&
                    pathData.getDestPdfPath().equals("destPath.pdf");
        }));
    }

    @Test
     void testGetPdfService() {
        // Set up
        dmsMigrationAnnualDataApplication.setPdfService(pdfServiceMock);

        // Test
        PdfService returnedService = dmsMigrationAnnualDataApplication.getPdfService();

        // Verify
        assertEquals(pdfServiceMock, returnedService);
    }

    @Test
     void testSetPdfService() {
        // Set up
        dmsMigrationAnnualDataApplication.setPdfService(pdfServiceMock);

        // Test
        PdfService returnedService = dmsMigrationAnnualDataApplication.getPdfService();

        // Verify
        assertEquals(pdfServiceMock, returnedService);

    }

}
