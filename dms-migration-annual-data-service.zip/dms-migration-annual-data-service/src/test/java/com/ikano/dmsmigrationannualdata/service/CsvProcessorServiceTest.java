package com.ikano.dmsmigrationannualdata.service;

import com.ikano.dmsmigrationannualdata.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CsvProcessorServiceTest {

    @InjectMocks
    private CsvProcessorService csvProcessorService;
    @Mock
    private SpringTemplateEngine templateEngine;
    @InjectMocks
    private PdfService pdfService;
    @Mock
    CustomerData customerData;
    @Mock
    private Headings headingsConfig;
    @Mock
    private SummaryData summaryData;
    @Mock
    private AccountData mockAccountData;
    @Mock
    private PathData pathData;

    @Mock
    private LinkedHashMap<String, String> headingsTranslation;


    private static final Logger LOGGER = LoggerFactory.getLogger(CsvProcessorServiceTest.class);

    @BeforeEach
    public void setUp() {

        MockitoAnnotations.initMocks(this);
        pathData = new PathData();
        pathData.setAccountDataCsv("csv");
        pathData.setDestPdfPath("pfdf");
        pathData.setSummaryDataCsv("summmary");
        summaryData = new SummaryData();
        summaryData.setSummaryYear("Janauary");
        summaryData.setSumPaidInterest("1223");
        summaryData.setSumReceivedInterest("233");
        summaryData.setSumPreliminaryTax("12");
        customerData = new CustomerData();
        customerData.setSummaryData(summaryData);
        headingsConfig = new Headings();
        new AccountData();
    }

    @Test
    void testRemoveDuplicates() {
        // Mock input data
        List<String[]> datas = new ArrayList<>();
        datas.add(new String[]{"1", "John", "Doe"});
        datas.add(new String[]{"2", "Jane", "Doe"});
        datas.add(new String[]{"1", "John", "Doe"}); // Duplicate of first row
        datas.add(new String[]{"3", "Alice", "Smith"});

        List<String> headings = Arrays.asList("ID", "First Name", "Last Name");
        Headings headings1 = new Headings();
        headings1.setSsn("abac");

        // Call the method
        LinkedHashMap<String, List<String[]>> result = csvProcessorService.removeDuplicates(datas, headings);

        // Assert the result
        assertNotNull(result);

        // Assert individual entries
        assertEquals(3, result.size()); // Only unique entries should be present
        assertTrue(result.containsKey("1"));
        assertTrue(result.containsKey("2"));
        assertTrue(result.containsKey("3"));

        assertEquals(1, result.get("1").size()); // Only one entry with ID "1"
        assertEquals(1, result.get("2").size()); // Only one entry with ID "2"
        assertEquals(1, result.get("3").size()); // Only one entry with ID "3"

        // Assert data integrity
        assertArrayEquals(new String[]{"1", "John", "Doe"}, result.get("1").get(0));
        assertArrayEquals(new String[]{"2", "Jane", "Doe"}, result.get("2").get(0));
        assertArrayEquals(new String[]{"3", "Alice", "Smith"}, result.get("3").get(0));
    }

    @Test
    void parseAndSplitInputData() {
        // Prepare input data
        List<String> inputLines = Arrays.asList(
                "\uFEFF1;John;Doe",
                "2;Jane;Smith"
        );

        // Call the method under test
        List<String[]> processedData = csvProcessorService.parseAndSplitInputData(inputLines);

        // Assert the result
        assertEquals(2, processedData.size());

        // Check the first data array
        String[] firstData = processedData.get(0);
        assertEquals(3, firstData.length);
        assertEquals("1", firstData[0]);
        assertEquals("John", firstData[1]);
        assertEquals("Doe", firstData[2]);

        // Check the second data array
        String[] secondData = processedData.get(1);
        assertEquals(3, secondData.length);
        assertEquals("2", secondData[0]);
        assertEquals("Jane", secondData[1]);
        assertEquals("Smith", secondData[2]);
    }

    @Test
    void testGeneratePdf() throws Exception {
        // Mocking
        PathData pathData = new PathData();
        when(templateEngine.process(anyString(), any(Context.class))).thenReturn("htmlContent");

        // Test
        String result = pdfService.generatePdf(pathData, customerData);

        // Verification
        assertNotNull(result);
        assertTrue(result.contains(".pdf"));
    }

    @Test
    void testFormatData() {
        // Test case with a valid numeric string
        String validNumericString = "1234.5678";
        String expectedResultForValid = "1,234.57";
        assertEquals(expectedResultForValid, csvProcessorService.formatData(validNumericString));

        // Test case with a non-numeric string
        String nonNumericString = "abcd";
        assertEquals(nonNumericString, csvProcessorService.formatData(nonNumericString));

        // Test case with an empty string
        String emptyString = "";
        assertEquals(emptyString, csvProcessorService.formatData(emptyString));

        // Test case with null input
        assertThrows(NullPointerException.class, () -> csvProcessorService.formatData(null));
    }

    @Test
    void testTranslationMapper_WhenHeadingsTranslationIsNull() throws Exception {
        // Arrange
        Field field = CsvProcessorService.class.getDeclaredField("headingsTranslation");
        field.setAccessible(true);
        field.set(csvProcessorService, null);

        // Act
        csvProcessorService.translationMapper();

        // Assert
        assertNotNull(field.get(csvProcessorService));
        assertTrue(field.get(csvProcessorService) instanceof LinkedHashMap);

        LinkedHashMap<String, String> expectedTranslation = new LinkedHashMap<>();
        expectedTranslation.put("Interest1", "Aktuell räntesats");
        expectedTranslation.put("ReceivedInterest", "Inkomstränta");
        expectedTranslation.put("Balance", "Tillgodohavande");
        expectedTranslation.put("PreliminaryTax", "Preliminärskatt");
        expectedTranslation.put("CapitalSharePercentage", "Din andel av kapital");
        expectedTranslation.put("ReceivedInterestSharePercentage", "Din andel av ränta");
        expectedTranslation.put("PaidInterestSharePercentage", "Din andel av ränta");
        expectedTranslation.put("BalanceShare", "");
        expectedTranslation.put("ReceivedInterestShare", "");
        expectedTranslation.put("PaidInterest", "Utgiftsränta");
        expectedTranslation.put("Debth", "Skuld");
        expectedTranslation.put("InterestOverDesk", "Utbetalt belopp");

        assertEquals(expectedTranslation, field.get(csvProcessorService));
    }

    @Test
    void testTranslationMapper_WhenHeadingsTranslationIsNotNull() throws Exception {
        // Arrange
        LinkedHashMap<String, String> existingTranslation = new LinkedHashMap<>();
        existingTranslation.put("ExistingKey", "ExistingValue");
        Field field = CsvProcessorService.class.getDeclaredField("headingsTranslation");
        field.setAccessible(true);
        field.set(csvProcessorService, existingTranslation);

        // Act
        csvProcessorService.translationMapper();

        // Assert
        assertNotNull(field.get(csvProcessorService));
        assertTrue(field.get(csvProcessorService) instanceof LinkedHashMap);

        // Ensure existing translation remains unchanged
        assertEquals(existingTranslation, field.get(csvProcessorService));
    }

    @Test
    void testGetFileData() throws IOException {
        // Test file path
        String testFilePath = "testfile.txt";

        // Create a test file with some content
        Files.write(Paths.get(testFilePath), "Test data\nSecond line".getBytes());

        // Initialize your class
        CsvProcessorService csvProcessorService = new CsvProcessorService(headingsConfig);
        csvProcessorService.setHeadingsConfig(headingsConfig);

        // Test when file exists
        List<String> fileData = csvProcessorService.getFileData(testFilePath);
        assertNotNull(fileData);
        assertEquals("Test data", fileData.get(0));
        assertEquals("Second line", fileData.get(1));

        // Clean up test file
        Files.deleteIfExists(Paths.get(testFilePath));
    }

    @Test
    void testValidatePathdata() throws FileNotFoundException, IllegalArgumentException, NullPointerException {
        // Initialize your class
        CsvProcessorService csvProcessorService = new CsvProcessorService(headingsConfig);
        csvProcessorService.setHeadingsConfig(headingsConfig);

        // Create a PathData object with valid paths
        PathData validPathData = new PathData();
        validPathData.setAccountDataCsv("valid_account_data.csv");
        validPathData.setSummaryDataCsv("valid_summary_data.csv");
        validPathData.setDestPdfPath("valid_dest_pdf.pdf");

        // Create some test files
        createTestFile("valid_account_data.csv");
        createTestFile("valid_summary_data.csv");

        // Test when pathData is not null and all paths are valid
        PathData validatedPathData = csvProcessorService.validatePathdata(validPathData);
        assertNotNull(validatedPathData);
        assertEquals(validPathData, validatedPathData);

        // Clean up test files
        deleteTestFile("valid_account_data.csv");
        deleteTestFile("valid_summary_data.csv");
    }


    void createTestFile(String filename) {
        try {
            Files.createFile(Paths.get(filename));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void deleteTestFile(String filename) {
        try {
            Files.deleteIfExists(Paths.get(filename));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void testGetFileData_FileExists() throws IOException {
        // Test file path
        String testFilePath = "testfile.txt";

        // Create a test file with some content
        Files.write(Paths.get(testFilePath), "Test data\nSecond line".getBytes());

        // Initialize the CsvProcessorService
        CsvProcessorService csvProcessorService = new CsvProcessorService(headingsConfig);
        csvProcessorService.setHeadingsConfig(headingsConfig);

        // Test when file exists
        List<String> fileData = csvProcessorService.getFileData(testFilePath);
        assertNotNull(fileData);
        assertEquals("Test data", fileData.get(0));
        assertEquals("Second line", fileData.get(1));

        // Clean up test file
        Files.deleteIfExists(Paths.get(testFilePath));
    }


    @Test
    void testGetIndexOfHeadingWhenHeadingExists() {
        // Mock data
        List<String> headings = Arrays.asList("Header1", "Header2", "Header3");
        String heading = "Header2";

        // Call the method
        int result = csvProcessorService.getIndexOfHeading(headings, heading);

        // Expected result
        int expectedResult = 1;

        // Assertion
        assertEquals(expectedResult, result);
    }

    @Test
    void testGetIndexOfHeadingWhenHeadingDoesNotExist() {
        // Mock data
        List<String> headings = Arrays.asList("Header1", "Header2", "Header3");
        String heading = "NonExistingHeader";

        // Call the method
        int result = csvProcessorService.getIndexOfHeading(headings, heading);

        // Expected result (since the heading does not exist, it should return 0)
        int expectedResult = 0;

        // Assertion
        assertEquals(expectedResult, result);
        // Verify the error message logged
        // You can use your preferred logging library or just print it out
        LOGGER.info("Logged error message: Heading not found: {}", heading);
    }


    @Test
    void testPrecedingZeroRemover() {
        // Test case with preceding zeros
        char[] testDataWithPrecedingZeros = {'0', '0', '0', '1', '2', '3', '4'};
        String resultWithPrecedingZeros = csvProcessorService.preceddingZeroRemover(testDataWithPrecedingZeros);
        assertEquals("1234", resultWithPrecedingZeros);

        // Test case without preceding zeros
        char[] testDataWithoutPrecedingZeros = {'1', '2', '3', '4'};
        String resultWithoutPrecedingZeros = csvProcessorService.preceddingZeroRemover(testDataWithoutPrecedingZeros);
        assertEquals("1234", resultWithoutPrecedingZeros);

        // Test case with all zeros
        char[] testDataAllZeros = {'0', '0', '0', '0'};
        String resultAllZeros = csvProcessorService.preceddingZeroRemover(testDataAllZeros);
        assertEquals("", resultAllZeros);

        // Test case with empty array
        char[] testDataEmptyArray = {};
        String resultEmptyArray = csvProcessorService.preceddingZeroRemover(testDataEmptyArray);
        assertEquals("", resultEmptyArray);
    }

    @Test
    void testIfAccountClosed() {
        // Creating sample AccountData object
        AccountData accountData = new AccountData();
        List<DataHolder> dataHolderList = new ArrayList<>();
        accountData.setDataHolder(dataHolderList);

        // Testing when account is closed
        String statusTextClosed = "AVSLUTAD";
        csvProcessorService.ifAccountClosed(statusTextClosed, accountData);
        assertEquals(1, accountData.getDataHolder().size());
        // assertEquals("Kontot avslutat", accountData.getDataHolder().get(0).getDataHeader());

        // Testing when account is not closed
        String statusTextNotClosed = "ÖPPEN";
        csvProcessorService.ifAccountClosed(statusTextNotClosed, accountData);
        assertEquals(1, accountData.getDataHolder().size()); // Size should remain the same
    }

    @Test
    void testLoadIndexesForAccount() {

        List<String> headings = Arrays.asList("heading1", "heading2", "heading3");
        String targetHeadings = "heading2,heading3";
        Integer[] result = csvProcessorService.loadIndexesForAccount(headings, targetHeadings);

        Integer[] expected = {1, 2};
        assertArrayEquals(expected, result);
    }

    @Test
    void testLoanAccount() {
        // Mocking necessary data
        AccountData accountData = new AccountData();
        List<DataHolder> listOfData = new ArrayList<>();
        accountData.setDataHolder(listOfData);
        String[] datas = new String[]{"100", "200", "300", "400", "500"};
        Integer[] loanAccountIndexes = new Integer[]{1, 2, 3, 4};
        csvProcessorService.setAccountDataHeadings(Arrays.asList("1", "2", "3", "4"));
        csvProcessorService.setHeadingsConfig(headingsConfig);
        csvProcessorService.setHeadingsTranslation(headingsTranslation);

        csvProcessorService.loanAccount(accountData, datas, loanAccountIndexes);

        assertEquals(2, listOfData.size());
        assertEquals("200.00", listOfData.get(0).getDataContent());
        assertEquals("300.00", listOfData.get(1).getDataContent());
        assertEquals("400.00", accountData.getBalanceShare());
        assertEquals("500.00", accountData.getInterestShare());
    }

    @Test
    void testSavingsAccount() {
        // Mocking necessary data
        AccountData accountData = new AccountData();
        accountData.setBalanceShare("100");
        accountData.setInterestShare("500");
        DataHolder dataHolder = new DataHolder();
        dataHolder.setDataHeader("pdf");
        dataHolder.setDataContent("csv");
        List<DataHolder> listOfData = new ArrayList<>();
        listOfData.add(dataHolder);
        accountData.setDataHolder(listOfData);
        String[] datas = new String[]{"100", "200", "300", "400", "500"};
        Integer[] savingsAccountIndexes = new Integer[]{1, 2, 3, 4};

        csvProcessorService.setAccountDataHeadings(Arrays.asList("1", "2", "3", "4"));
        csvProcessorService.setHeadingsConfig(headingsConfig);
        csvProcessorService.setHeadingsTranslation(headingsTranslation);
        // Calling the method
        csvProcessorService.savingsAccount(accountData, datas, savingsAccountIndexes);

        // Verifying the behavior
        assertEquals(3, listOfData.size());
        assertEquals("csv", listOfData.get(0).getDataContent());
        assertEquals("400.00", accountData.getBalanceShare());
        assertEquals("500.00", accountData.getInterestShare());

    }

    @Test
    void testTillvaxtAccount() {
        // Mocking necessary data
        AccountData accountData = new AccountData();
        List<DataHolder> listOfData = new ArrayList<>();
        accountData.setDataHolder(listOfData);
        String[] datas = new String[]{"AVSLUTAD", "100", "200", "300", "400", "500"};
        Integer[] tillvaxtAccountIndexes = new Integer[]{1, 2, 3, 4, 5};

        csvProcessorService.setAccountDataHeadings(Arrays.asList("1", "2", "3", "4"));
        csvProcessorService.setHeadingsConfig(headingsConfig);
        csvProcessorService.setHeadingsTranslation(headingsTranslation);


        csvProcessorService.tillvaxtAccount(accountData, datas, tillvaxtAccountIndexes);

        // Verifying the behavior
        assertEquals(3, listOfData.size());
        assertEquals("100.00", listOfData.get(0).getDataContent());
        assertEquals("200.00", listOfData.get(1).getDataContent());
        assertEquals("400.00", accountData.getBalanceShare());
        assertEquals("500.00", accountData.getInterestShare());
    }

    @Test
    void testBorsAccount_AccountClosed() {
        // Mocking necessary data
        AccountData accountData = new AccountData();
        List<DataHolder> listOfData = new ArrayList<>();
        accountData.setDataHolder(listOfData);

        String[] datas = new String[]{"AVSLUTAD", "100", "200"};
        csvProcessorService.setAccountDataHeadings(Arrays.asList("1", "2", "3", "4"));
        csvProcessorService.setHeadingsConfig(headingsConfig);
        csvProcessorService.setHeadingsTranslation(headingsTranslation);


        csvProcessorService.borsAccount(accountData, datas);

        // Verifying the behavior
        assertEquals(2, listOfData.size());
        assertEquals("AVSLUTAD", listOfData.get(0).getDataContent());
        assertEquals("AVSLUTAD", listOfData.get(1).getDataContent());
    }

    @Test
    void testBorsAccount_AccountNotClosed() {
        // Mocking necessary data
        AccountData accountData = new AccountData();
        List<DataHolder> listOfData = new ArrayList<>();
        accountData.setDataHolder(listOfData);
        String[] datas = new String[]{"OPEN", "100"};
        assertEquals(0, listOfData.size());

    }

}

