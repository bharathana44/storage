package com.ikano.dmsmigrationannualdata.model;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CustomerDataTest {
    private CustomerData customerData;

    @BeforeEach
     void setUp() {
        customerData = new CustomerData();
    }

    @Test
     void testSSN() {
        // Set SSN
        String ssn = "123-45-6789";
        customerData.setSsn(ssn);

        // Verify SSN
        assertEquals(ssn, customerData.getSsn());
    }

    @Test
     void testCustomerName() {
        // Set customer name
        String customerName = "John Doe";
        customerData.setCustomerName(customerName);

        // Verify customer name
        assertEquals(customerName, customerData.getCustomerName());
    }

    @Test
     void testCareOfAddress() {
        // Set care of address
        String careOfAddress = "Jane Doe";
        customerData.setCareOfAddress(careOfAddress);

        // Verify care of address
        assertEquals(careOfAddress, customerData.getCareOfAddress());
    }

    @Test
     void testStreetName() {
        // Set street name
        String streetName = "123 Main Street";
        customerData.setStreetName(streetName);

        // Verify street name
        assertEquals(streetName, customerData.getStreetName());
    }

    @Test
     void testCity() {
        // Set city
        String city = "New York";
        customerData.setCity(city);

        // Verify city
        assertEquals(city, customerData.getCity());
    }

    @Test
     void testPincode() {
        // Set pincode
        String pincode = "10001";
        customerData.setPincode(pincode);

        // Verify pincode
        assertEquals(pincode, customerData.getPincode());
    }

    @Test
     void testAccountData() {
        // Create account data list
        List<AccountData> accountDataList = new ArrayList<>();
        accountDataList.add(new AccountData());
        accountDataList.add(new AccountData());

        // Set account data list
        customerData.setAccountData(accountDataList);

        // Verify account data list
        assertEquals(accountDataList, customerData.getAccountData());
    }

    @Test
     void testSummaryData() {
        // Create summary data
        SummaryData summaryData = new SummaryData();

        // Set summary data
        customerData.setSummaryData(summaryData);

        // Verify summary data
        assertNotNull(customerData.getSummaryData());
        assertEquals(summaryData, customerData.getSummaryData());
    }
}