package com.ikano.dmsmigrationannualdata.model;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DataHolderTest {
    private DataHolder dataHolder;

    @BeforeEach
    public void setUp() {
        dataHolder = new DataHolder();
    }

    @Test
    void testDataHeader() {
        // Set data header
        String dataHeader = "Header";
        dataHolder.setDataHeader(dataHeader);

        // Verify data header
        assertEquals(dataHeader, dataHolder.getDataHeader());
    }

    @Test
    void testDataContent() {
        // Set data content
        String dataContent = "Content";
        dataHolder.setDataContent(dataContent);

        // Verify data content
        assertEquals(dataContent, dataHolder.getDataContent());
    }
}