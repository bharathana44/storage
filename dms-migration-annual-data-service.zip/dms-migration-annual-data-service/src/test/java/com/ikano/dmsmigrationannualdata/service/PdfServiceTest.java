package com.ikano.dmsmigrationannualdata.service;

import com.ikano.dmsmigrationannualdata.model.CustomerData;
import com.ikano.dmsmigrationannualdata.model.PathData;
import com.ikano.dmsmigrationannualdata.model.SummaryData;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.nio.file.Files;
import java.nio.file.Paths;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PdfServiceTest {
    @Mock
    private SpringTemplateEngine templateEngine;

    @Mock
    private SummaryData summaryData;
    @Mock
    CustomerData customerData;

    @InjectMocks
    private PdfService pdfService;

    @BeforeEach
     void setUp() {
        MockitoAnnotations.initMocks(this);
        summaryData = new SummaryData();
        summaryData.setSummaryYear("Janauary");
        summaryData.setSumPaidInterest("1223");
        summaryData.setSumReceivedInterest("233");
        summaryData.setSumPreliminaryTax("12");
        customerData = new CustomerData();
        customerData.setSummaryData(summaryData);
    }

    @Test
    void testGeneratePdf() throws Exception {
        PathData pathData = new PathData();
        when(templateEngine.process(anyString(), any(Context.class))).thenReturn("htmlContent");
        String result = pdfService.generatePdf(pathData, customerData);
        Assertions.assertNotNull(result);
        Assertions.assertTrue(result.contains(".pdf"));
    }

    @Test
    void testRenderPdfUsingIText() throws Exception {
        String html = "<html><body><h1>Hello, World!</h1></body></html>";
        String destPath = "test.pdf";
        String result = pdfService.renderPdfUsingIText(html, destPath);
        Assertions.assertTrue(Files.exists(Paths.get(destPath)));
        Assertions.assertEquals(destPath, result);
        Files.deleteIfExists(Paths.get(destPath));
    }

    @Test
    void testLoadAndFillTemplate() throws Exception {
        Context context = new Context();
        context.setVariable("testVar", "testValue");
        when(templateEngine.process(anyString(), any(Context.class))).thenReturn("htmlContent");
        String result = pdfService.loadAndFillTemplate(context);

        Assertions.assertEquals("htmlContent", result);
    }

}