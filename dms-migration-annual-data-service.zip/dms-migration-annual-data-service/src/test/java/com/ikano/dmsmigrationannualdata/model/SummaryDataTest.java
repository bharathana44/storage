package com.ikano.dmsmigrationannualdata.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SummaryDataTest {
    @Test
    void testSummaryYear() {
        // Given
        String expectedYear = "2023";
        SummaryData summaryData = new SummaryData();

        // When
        summaryData.setSummaryYear(expectedYear);

        // Then
        assertEquals(expectedYear, summaryData.getSummaryYear());
    }

    @Test
    void testSumReceivedInterest() {
        // Given
        String expectedInterest = "1000.50";
        SummaryData summaryData = new SummaryData();

        // When
        summaryData.setSumReceivedInterest(expectedInterest);

        // Then
        assertEquals(expectedInterest, summaryData.getSumReceivedInterest());
    }

    @Test
    void testSumPreliminaryTax() {
        // Given
        String expectedTax = "500.75";
        SummaryData summaryData = new SummaryData();

        // When
        summaryData.setSumPreliminaryTax(expectedTax);

        // Then
        assertEquals(expectedTax, summaryData.getSumPreliminaryTax());
    }

    @Test
    void testSumPaidInterest() {
        // Given
        String expectedInterest = "750.25";
        SummaryData summaryData = new SummaryData();

        // When
        summaryData.setSumPaidInterest(expectedInterest);

        // Then
        assertEquals(expectedInterest, summaryData.getSumPaidInterest());
    }
}



