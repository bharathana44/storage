package com.ikano.dmsmigrationannualdata.service;


import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.zip.DataFormatException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import com.ikano.dmsmigrationannualdata.model.AccountData;
import com.ikano.dmsmigrationannualdata.model.CustomerData;
import com.ikano.dmsmigrationannualdata.model.DataHolder;
import com.ikano.dmsmigrationannualdata.model.Headings;
import com.ikano.dmsmigrationannualdata.model.PathData;
import com.ikano.dmsmigrationannualdata.model.SummaryData;

@Service
public class CsvProcessorService {

    @Autowired
    @Lazy
    private PdfService pdfService;
    private List<String> accountDataHeadings;
    private List<String> summaryDataHeadings;
    private Map<String, List<String[]>> accountData;
    private Map<String, List<String[]>> summaryData;
    private Map<String, String> headingsTranslation;
    private static final String DEFAULT_HEADING = "HeadingDefault";
    private static final String RECEIVED_INTREST = "ReceivedInterest";
    private static final String BALANCE = "Balance";
    private static final String INTREST_OVER_DESK = "InterestOverDesk";

    private static final Logger LOGGER = LoggerFactory.getLogger(CsvProcessorService.class);

    private Headings headingsConfig;

    CsvProcessorService(Headings headingsConfig) {
        this.headingsConfig = headingsConfig;

    }

    @Async
    public void generatePdf(PathData pathData) throws IOException {
        if (pathData != null) {
            validatePathdata(pathData);
            String destPdfPath = pathData.getDestPdfPath();
            if (destPdfPath == null) {
                destPdfPath = headingsConfig.getPdfDestPath();
                pathData.setDestPdfPath(destPdfPath);
            }
        } else {
            LOGGER.warn("PathData is null. Skipping path validation and setting default PDF destination path.");
            return; // Return early if pathData is null
        }

        processCustomerDataCustom(pathData.getAccountDataCsv());
        processSummaryDataCustom(pathData.getSummaryDataCsv());
        translationMapper();

        List<CustomerData> customerDatas = null;

        try {
            customerDatas = loadAllData();
        } catch (Exception e) {
            LOGGER.error("An unexpected error occurred: {}", e.getMessage(), e);
        } finally {
            accountDataHeadings.clear();
            summaryDataHeadings.clear();
            accountData.clear();
            summaryData.clear();
        }

        LOGGER.info("\n<<<<< PDF Generation Started >>>>>\n");
        if (customerDatas != null) {
            customerDatas.forEach(customerData -> {
                try {
                    LOGGER.info("Generating PDF...");
                    pdfService.generatePdf(pathData, customerData);
                    LOGGER.info("PDF generation completed.");
                } catch (Exception e) {
                    LOGGER.error("Error Generating PDF : [ {} ]", pathData.getDestPdfPath() + String.format("%s_%s.pdf", customerData.getSsn(), customerData.getSummaryData().getSummaryYear()));
                }
            });
        }
        LOGGER.info("\n<<<<< PDF Generation Completed >>>>>\n");
    }

    void processCustomerDataCustom(String sourcePath) throws IOException {
        sourcePath = sourcePath == null ? headingsConfig.getAccountCSVDefaultPath() : sourcePath;

        List<String> inputLines = List.of();
        try {
            inputLines = getFileData(sourcePath);
        } catch (IOException e) {
            // Handle the specific exception (e.g., log, rethrow, or recover)
            LOGGER.error("Error reading file: {}", sourcePath, e);
        }

        List<String[]> inputData = parseAndSplitInputData(inputLines);

        accountDataHeadings = new LinkedList<>(List.of(inputData.remove(0)));
        accountData = removeDuplicates(inputData, accountDataHeadings);
    }

    void processSummaryDataCustom(String sourcePath) throws IOException {

        sourcePath = sourcePath == null ? headingsConfig.getSummaryCSVDefaultPath() : sourcePath;

        List<String> fileData = getFileData(sourcePath);
        List<String[]> linesData = parseAndSplitInputData(fileData);

        summaryDataHeadings = new LinkedList<>(Arrays.asList(linesData.remove(0)));
        summaryData = removeDuplicates(linesData, summaryDataHeadings);

    }

    List<String[]> parseAndSplitInputData(List<String> inputLines) {

        return inputLines.stream().map(line -> {

            String[] datas = line.split(";");

            for (var i = 0; i < datas.length; i++) {

                datas[i] = datas[i].replace("\"", "").replace("\uFEFF", "").trim();

            }

            return datas;

        }).collect(Collectors.toList());

    }

    LinkedHashMap<String, List<String[]>> removeDuplicates(List<String[]> datas, List<String> headings) {

        Map<String, List<String[]>> datasMap = datas.stream().collect(Collectors.groupingBy(inputDatas -> inputDatas[getIndexOfHeading(headings, headingsConfig.getSsn())], LinkedHashMap<String, List<String[]>>::new, Collectors.mapping(Function.identity(), Collectors.toList())));

        return datasMap.entrySet().stream().map(entry -> {

            List<String[]> dataList = entry.getValue();

            return dataList.stream().map(inputDatas -> {
                        var stringJoiner = new StringJoiner(";");

                        for (String inputData : inputDatas) {

                            stringJoiner.add(inputData);

                        }

                        return stringJoiner.toString();

                    }).distinct()
                    .map(uniqueData -> {

                        return uniqueData.split(";");

                    });

        }).flatMap(Function.identity()).collect(Collectors.groupingBy(processedData -> processedData[getIndexOfHeading(headings, headingsConfig.getSsn())], LinkedHashMap<String, List<String[]>>::new, Collectors.mapping(Function.<String[]>identity(), Collectors.toList())));

    }

    private List<AccountData> loadAccountDataCustom(List<String[]> inputData) {

        Integer[] savingsAccountIndexes = loadIndexesForAccount(accountDataHeadings, headingsConfig.getSavingsAccount());
        Integer[] loanAccountIndexes = loadIndexesForAccount(accountDataHeadings, headingsConfig.getLoanAccount());
        Integer[] tillvaxtAccountIndexes = loadIndexesForAccount(accountDataHeadings, headingsConfig.getTillVaxtAccount());


        return inputData.stream().map(datas -> {

            List<DataHolder> listOfData = new LinkedList<>();

            String accountId = preceddingZeroRemover(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getEngagementNumber())].toCharArray());

            var accountData1 = new AccountData();

            accountData1.setAccountName(String.join(" ", datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getProductText())], accountId));
            accountData1.setDataHolder(listOfData);

            String customerAccountType = datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getEngagementType())];
            String productText = datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getProductText())];

            switch (customerAccountType) {
                case "":
                    savingsAccount(accountData1, datas, savingsAccountIndexes);
                    break;
                case "D":
                    savingsAccount(accountData1, datas, savingsAccountIndexes);
                    break;
                case "T":
                    if (productText.toLowerCase().contains("TILLVÄXT".toLowerCase())) {
                        tillvaxtAccount(accountData1, datas, tillvaxtAccountIndexes);
                    } else if (productText.toLowerCase().contains("BÖRS".toLowerCase())) {
                        borsAccount(accountData1, datas);
                    } else if (productText.toLowerCase().contains("SPARKONTO FIX".toLowerCase()) || productText.toLowerCase().contains("SPARKTO FIX".toLowerCase()) || productText.toLowerCase().contains("FÖRETAGSKTO FIX".toLowerCase())) {
                        savingsAccount(accountData1, datas, savingsAccountIndexes);
                    }
                    break;
                case "L":
                    loanAccount(accountData1, datas, loanAccountIndexes);
                    break;
                default:
                    break;
            }
            return accountData1;
        }).collect(Collectors.toList());

    }

    private SummaryData loadSummaryData(List<String[]> linesData) throws DataFormatException {

        var summaryDataOut = linesData.stream().map(datas -> {

            var summaryData1 = new SummaryData();

            summaryData1.setSummaryYear(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getYearConcerned())]);
            summaryData1.setSumReceivedInterest(formatData(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getSumReceivedInterest())]));
            summaryData1.setSumPreliminaryTax(formatData(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getSumPreliminaryTax())]));
            summaryData1.setSumPaidInterest(formatData(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getSumPaidInterest())]));

            return summaryData1;

        }).findFirst().orElseThrow(() -> new DataFormatException("Summary data loading failed :("));

        return summaryDataOut;

    }

    private CustomerData loadCustomerData(List<String[]> inputDatas, CustomerData customerData) {

        inputDatas.forEach(datas -> {

            customerData.setCustomerName(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getName())]);
            customerData.setCareOfAddress(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getCareOfAddress())]);
            customerData.setStreetName(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getStreetAddress())]);
            customerData.setPincode(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getPostalCode())]);
            customerData.setCity(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getCity())]);

        });

        return customerData;

    }

    public List<CustomerData> loadAllData() {
        try {
            return accountData.entrySet().stream().map(entry -> {
                var customerData = new CustomerData();
                String ssn = entry.getKey();
                List<AccountData> customerAccountData = loadAccountDataCustom(entry.getValue());
                SummaryData customerSummaryData = null;
                try {
                    if (summaryData.containsKey(ssn)) {
                        customerSummaryData = loadSummaryData(summaryData.get(ssn));
                        customerData = loadCustomerData(summaryData.get(ssn), customerData);
                    }
                } catch (DataFormatException e) {
                    LOGGER.error("DataFormatException:", e);
                    LOGGER.error("Error loading data for SSN: " + ssn, e);
                }
                customerData.setSsn(ssn);
                customerData.setAccountData(customerAccountData);
                customerData.setSummaryData(customerSummaryData);
                return customerData;
            }).collect(Collectors.toList());
        } catch (Exception e) {
            // Catch any other unexpected exceptions and wrap them in the custom exception
            LOGGER.error("Unexpected error occurred while loading data", e);
        }
        return List.of();
    }

    void savingsAccount(AccountData accountData, String[] datas, Integer[] savingsAccountIndexes) {

        List<DataHolder> listOfData = accountData.getDataHolder();

        for (var i = 0; i < savingsAccountIndexes.length - 2; i++) {

            Integer indexToFetch = savingsAccountIndexes[i];

            if (!(accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getCapitalSharePercentage()) || accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getReceivedInterestSharePercentage()))) {

                datas[indexToFetch] = formatData(datas[indexToFetch]);

            } else {
                datas[indexToFetch] = String.format("%.0f", Double.parseDouble(datas[indexToFetch]));
            }

            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(indexToFetch), DEFAULT_HEADING), (i == 0) ? datas[indexToFetch] + "%" : datas[indexToFetch]));

        }

        Integer indexToFetch = savingsAccountIndexes.length;

        accountData.setBalanceShare(formatData(datas[savingsAccountIndexes[indexToFetch - 2]]));
        accountData.setInterestShare(formatData(datas[savingsAccountIndexes[indexToFetch - 1]]));

        ifAccountClosed(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getStatusText())], accountData);

    }

    void loanAccount(AccountData accountData, String[] datas, Integer[] loanAccountIndexes) {

        List<DataHolder> listOfData = accountData.getDataHolder();

        for (var i = 0; i < loanAccountIndexes.length - 2; i++) {

            Integer indexToFetch = loanAccountIndexes[i];

            if (!(accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getCapitalSharePercentage()) || accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getPaidInterestSharePercentage()))) {

                datas[indexToFetch] = formatData(datas[indexToFetch]);

            } else {
                datas[indexToFetch] = String.format("%.0f", Double.parseDouble(datas[indexToFetch]));
            }

            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(indexToFetch), DEFAULT_HEADING), datas[indexToFetch]));

        }

        Integer indexToFetch = loanAccountIndexes.length;

        accountData.setBalanceShare(formatData(datas[loanAccountIndexes[indexToFetch - 2]]));
        accountData.setInterestShare(formatData(datas[loanAccountIndexes[indexToFetch - 1]]));

        ifAccountClosed(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getStatusText())], accountData);

    }

    void tillvaxtAccount(AccountData accountData, String[] datas, Integer[] tillvaxtAccountIndexes) {

        List<DataHolder> listOfData = accountData.getDataHolder();

        if (isAccountClosed(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getStatusText())]) || Double.valueOf(datas[getIndexOfHeading(accountDataHeadings, RECEIVED_INTREST)]) > 0 || Double.valueOf(datas[getIndexOfHeading(accountDataHeadings, "PreliminaryTax")]) > 0) {

            for (var i = 0; i < tillvaxtAccountIndexes.length - 2; i++) {

                Integer indexToFetch = tillvaxtAccountIndexes[i];

                if (!(accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getCapitalSharePercentage()) || accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getReceivedInterestSharePercentage()))) {

                    datas[indexToFetch] = formatData(datas[indexToFetch]);

                } else {
                    datas[indexToFetch] = String.format("%.0f", Double.parseDouble(datas[indexToFetch]));
                }

                listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(indexToFetch), DEFAULT_HEADING), datas[indexToFetch]));

            }

            Integer indexToFetch = tillvaxtAccountIndexes.length;

            accountData.setBalanceShare(formatData(datas[tillvaxtAccountIndexes[indexToFetch - 2]]));
            accountData.setInterestShare(formatData(datas[tillvaxtAccountIndexes[indexToFetch - 1]]));

        } else {

            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(getIndexOfHeading(accountDataHeadings, BALANCE)), DEFAULT_HEADING), formatData(datas[getIndexOfHeading(accountDataHeadings, BALANCE)])));
            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(getIndexOfHeading(accountDataHeadings, headingsConfig.getCapitalSharePercentage())), DEFAULT_HEADING), String.format("%.0f", Double.parseDouble(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getCapitalSharePercentage())]))));

            Integer indexToFetch = tillvaxtAccountIndexes.length;
            accountData.setBalanceShare(formatData(datas[tillvaxtAccountIndexes[indexToFetch - 2]]));

        }

    }

    void borsAccount(AccountData accountData, String[] datas) {

        List<DataHolder> listOfData = accountData.getDataHolder();

        if (isAccountClosed(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getStatusText())])) {

            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(getIndexOfHeading(accountDataHeadings, INTREST_OVER_DESK)), DEFAULT_HEADING), formatData(datas[getIndexOfHeading(accountDataHeadings, INTREST_OVER_DESK)])));
            listOfData.add(new DataHolder("Kapitalvinst", formatData(datas[getIndexOfHeading(accountDataHeadings, RECEIVED_INTREST)])));

        } else {

            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(getIndexOfHeading(accountDataHeadings, BALANCE)), DEFAULT_HEADING), formatData(datas[getIndexOfHeading(accountDataHeadings, BALANCE)])));

        }

    }

    Integer[] loadIndexesForAccount(List<String> headings, String targetHeadings) {

        String[] accountHeaders = targetHeadings.split(",");

        var accountIndexes = new Integer[accountHeaders.length];
        var indexOfIndexes = 0;

        for (String header : accountHeaders) {

            for (var i = 0; i < headings.size(); i++) {

                if (headings.get(i).equalsIgnoreCase(header)) {

                    accountIndexes[indexOfIndexes++] = i;
                    break;

                }

            }

        }

        return accountIndexes;

    }

    private boolean isAccountClosed(String statusText) {

        return statusText.equalsIgnoreCase("AVSLUTAD") || statusText.equalsIgnoreCase("AVSLUTAT");

    }

    void ifAccountClosed(String statusText, AccountData accountData) {

        if (statusText.equalsIgnoreCase("AVSLUTAD") || statusText.equalsIgnoreCase("AVSLUTAT")) {

            accountData.getDataHolder().add(new DataHolder("Kontot avslutat", ""));

        }

    }

    String formatData(String data) {

        try {

            Double doubleData = Double.parseDouble(data);

            return String.format("%,.2f", doubleData);

        } catch (NumberFormatException e) {

            return data;

        }

    }

    String preceddingZeroRemover(char[] dataArray) {

        for (var i = 0; i < dataArray.length; i++) {

            if (dataArray[i] != '0') {
                break;
            }

            dataArray[i] = ' ';

        }

        return String.valueOf(dataArray).stripLeading();

    }

    Integer getIndexOfHeading(List<String> headings, String heading) {

        if (headings.contains(heading)) {

            return headings.indexOf(heading);

        }

        LOGGER.error("Heading not found: {}", heading);

        return 0;
    }

    List<String> getFileData(String filePath) throws IOException {

        if (isFileExists(filePath)) {

            return Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);

        }

        LOGGER.error("File not found: [ {} ]", filePath);

        return List.of();
    }

    private Boolean isFileExists(String filePath) {

        return Files.exists(Paths.get(filePath));

    }

    PathData validatePathdata(PathData pathData) throws IllegalArgumentException, NullPointerException {

        if (pathData != null) {

            if (pathData.getAccountDataCsv() != null && pathData.getSummaryDataCsv() != null && pathData.getDestPdfPath() != null) {

                if (Files.exists(Paths.get(pathData.getAccountDataCsv())) && Files.exists(Paths.get(pathData.getSummaryDataCsv()))) {

                    return pathData;

                }

                LOGGER.error("Some of the input files not found: [ {} ]", String.join(", ", pathData.getAccountDataCsv(), pathData.getSummaryDataCsv()));

            }

            LOGGER.error("Some of the input files paths are null : [ " + String.join(", ", pathData.getAccountDataCsv(), pathData.getSummaryDataCsv()) + " ]");

        }

        LOGGER.error("Pathdata is null");

        return pathData;
    }

    void translationMapper() {

        if (headingsTranslation != null) return;

        headingsTranslation = new LinkedHashMap<>();

        headingsTranslation.put("Interest1", "Aktuell räntesats");
        headingsTranslation.put(RECEIVED_INTREST, "Inkomstränta");
        headingsTranslation.put(BALANCE, "Tillgodohavande");
        headingsTranslation.put("PreliminaryTax", "Preliminärskatt");
        headingsTranslation.put("CapitalSharePercentage", "Din andel av kapital");
        headingsTranslation.put("ReceivedInterestSharePercentage", "Din andel av ränta");
        headingsTranslation.put("PaidInterestSharePercentage", "Din andel av ränta");
        headingsTranslation.put("BalanceShare", "");
        headingsTranslation.put("ReceivedInterestShare", "");
        headingsTranslation.put("PaidInterest", "Utgiftsränta");
        headingsTranslation.put("Debth", "Skuld");
        headingsTranslation.put(INTREST_OVER_DESK, "Utbetalt belopp");

    }

    public void setPdfService(PdfService pdfService) {
        this.pdfService = pdfService;
    }

    public void setAccountDataHeadings(List<String> accountDataHeadings) {
        this.accountDataHeadings = accountDataHeadings;
    }

    public void setSummaryDataHeadings(List<String> summaryDataHeadings) {
        this.summaryDataHeadings = summaryDataHeadings;
    }

    public void setAccountData(Map<String, List<String[]>> accountData) {
        this.accountData = accountData;
    }

    public void setSummaryData(Map<String, List<String[]>> summaryData) {
        this.summaryData = summaryData;
    }

    public void setHeadingsTranslation(Map<String, String> headingsTranslation) {
        this.headingsTranslation = headingsTranslation;
    }

    public void setHeadingsConfig(Headings headingsConfig) {
        this.headingsConfig = headingsConfig;
    }
}