package com.ikano.dmsmigrationannualdata.model;

import java.util.List;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class AccountData {

    private String accountName;

    private List<DataHolder> dataHolder;

    private String balanceShare;

    private String interestShare;

}
