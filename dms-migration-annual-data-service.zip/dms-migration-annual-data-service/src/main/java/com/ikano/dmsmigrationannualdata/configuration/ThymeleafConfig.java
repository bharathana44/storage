
package com.ikano.dmsmigrationannualdata.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.thymeleaf.templateresolver.TemplateResolution;

@Configuration
@PropertySource("classpath:application.properties")
public class ThymeleafConfig {

    @Value("${csv.processor.default.account_csv_source_path}")
    private String accountCsvSourcePath;

    @Value("${csv.processor.default.summary_csv_source_path}")
    private String summaryCsvSourcePath;

    @Value("${csv.processor.default.pdf_dest_path}")
    private String pdfDestPath;
    @Value("${spring.thymeleaf.prefix}")
    private String thymeleafPrefix;

    @Value("${spring.thymeleaf.suffix}")
    private String thymeleafSuffix;

    @Bean
    public SpringTemplateEngine templateEngine() {
        SpringTemplateEngine templateEngine = new SpringTemplateEngine();
        templateEngine.setTemplateResolver(templateResolver());
        return templateEngine;
    }

    @Bean
    public ClassLoaderTemplateResolver templateResolver() {
        ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
        templateResolver.setPrefix("/templates/");
        templateResolver.setSuffix(".html");/*
        templateResolver.setTemplateMode("HTML");
        templateResolver.setCharacterEncoding("UTF-8");
        templateResolver.*/
        return templateResolver;
    }

}
