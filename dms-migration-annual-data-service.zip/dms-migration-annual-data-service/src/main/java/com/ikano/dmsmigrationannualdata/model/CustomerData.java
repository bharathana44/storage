package com.ikano.dmsmigrationannualdata.model;

import java.util.List;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CustomerData {

    private String ssn;

    private String customerName;

    private String careOfAddress;

    private String streetName;

    private String city;

    private String pincode;

    private List<AccountData> accountData;

    private SummaryData summaryData;

}
