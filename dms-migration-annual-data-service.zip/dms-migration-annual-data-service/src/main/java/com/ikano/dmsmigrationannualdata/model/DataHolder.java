package com.ikano.dmsmigrationannualdata.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DataHolder {

    private String dataHeader;

    private String dataContent;

}
