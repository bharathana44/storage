package com.ikano.dmsmigrationannualdata.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SummaryData {

    private String summaryYear;

    private String sumReceivedInterest;

    private String sumPreliminaryTax;

    private String sumPaidInterest;

}
