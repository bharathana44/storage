package com.ikano.dmsmigrationannualdata.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PathData {

    private String accountDataCsv;

    private String summaryDataCsv;

    private String destPdfPath;

}
