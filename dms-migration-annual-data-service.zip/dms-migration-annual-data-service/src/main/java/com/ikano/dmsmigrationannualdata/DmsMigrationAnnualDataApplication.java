package com.ikano.dmsmigrationannualdata;

import com.ikano.dmsmigrationannualdata.model.PathData;
import com.ikano.dmsmigrationannualdata.service.CsvProcessorService;
import com.ikano.dmsmigrationannualdata.service.PdfService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class DmsMigrationAnnualDataApplication implements CommandLineRunner {
  @Value("${csv.processor.default.account_csv_source_path}")
    private String accountDataCsv ;
    @Value("${csv.processor.default.summary_csv_source_path}")
    private String summaryDataCsv;
    @Value("${csv.processor.default.pdf_dest_path}")
    private String destPath;

  /* private String accountDataCsv = "D:/data/input/Dev1_YearlyStatementEngagements2022.csv";
    // @Value("${csv.processor.default.summary_csv_source_path}")
    private String summaryDataCsv = "D:/data/input/Dev1_YearlyStatementOverview2022.csv";
    // @Value("${csv.processor.default.pdf_dest_path}")
    private String destPath ="D:/data/output/output/";
  */  @Autowired
    private PdfService pdfService;
    @Autowired
    private CsvProcessorService csvProcessorService;



    private static final Logger LOGGER = LoggerFactory.getLogger(DmsMigrationAnnualDataApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(DmsMigrationAnnualDataApplication.class, args);
    }

    public void run(String[] args) {

        if (accountDataCsv == null || summaryDataCsv == null || destPath == null) {
            return;
        }
        var pathData = new PathData();
        pathData.setAccountDataCsv(accountDataCsv);
        pathData.setSummaryDataCsv(summaryDataCsv);
        pathData.setDestPdfPath(destPath);
        try {
            getCsvProcessorService().generatePdf(pathData);
        } catch (Exception e) {

            LOGGER.error("An error occurred:", e);
        }


    }

    public PdfService getPdfService() {
        return pdfService;
    }

    public void setPdfService(PdfService pdfService) {
        this.pdfService = pdfService;
    }

    public CsvProcessorService getCsvProcessorService() {
        return csvProcessorService;
    }

    public void setCsvProcessorService(CsvProcessorService csvProcessorService) {
        this.csvProcessorService = csvProcessorService;
    }

    public void setAccountDataCsv(String accountDataCsv) {
        this.accountDataCsv = accountDataCsv;
    }

    public void setSummaryDataCsv(String summaryDataCsv) {
        this.summaryDataCsv = summaryDataCsv;
    }

    public void setDestPath(String destPath) {
        this.destPath = destPath;
    }
}
